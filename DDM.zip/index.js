var image1 = document.getElementById("image1");
var image2 = document.getElementById("image2");
var selector = document.getElementById("selector");
var closeSelector = document.getElementById("closeSelector");
var nav = document.getElementById("navigation");
selector.addEventListener("click", function() {
	nav.style.opacity = "1";
  selector.style.opacity = "0";
  closeSelector.style.opacity = "1";
  closeSelector.style.zIndex = "2";
});
closeSelector.addEventListener("click", function() {
	nav.style.opacity = "0";
  selector.style.opacity = "1";
  closeSelector.style.opacity = "0";
  closeSelector.style.zIndex = "-1";
});
gallery();
function gallery() {
	twoFade();
	function twoFade() {
		window.setTimeout(function() {
			image2.style.opacity = "0";
			image1.style.opacity = "1";
			image2.style["box-shadow"] = null;
			oneFade();
		}, 4000);
	}
	function oneFade() {
		window.setTimeout(function() {
			image2.style.opacity = "1";
			image1.style.opacity = "0";
			image2.style["box-shadow"] = "0px 2px 30px 5px black";
			twoFade();
		}, 4000);
	}
}